<?php

namespace Dev\Banner\Model;

use Dev\Banner\Api\Data\BannerSearchResultInterface;
use Magento\Framework\Api\SearchResults;

class BannerSearchResult extends SearchResults implements BannerSearchResultInterface
{

}
